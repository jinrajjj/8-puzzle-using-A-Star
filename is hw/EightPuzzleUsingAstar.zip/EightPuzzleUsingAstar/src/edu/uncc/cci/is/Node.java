package edu.uncc.cci.is;

import java.util.ArrayList;

/**
 * Project 01
 * Authors: Ankit Pandita, Jinraj Jain
 */

public class Node {
	public int aStarDistance;
	public int level;
	public int heuristicDistance;
	public int[][] stateOfPuzzle;
}
